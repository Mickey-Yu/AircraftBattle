#导入模块
import pygame
import random
from pygame.locals import *
from os import path

#######################################基本参数配置#######################################

#获取图片库和声音库路径
img_dir = path.join(path.dirname(__file__),'pic')
sound_folder = path.join(path.dirname(__file__),'sounds')

#定义游戏窗口、玩家血量条尺寸，游戏运行速度、炮火持续时间等参数
WIDTH = 480
HEIGHT = 600
FPS = 60
POWERUP_TIME = 5000
BAR_LENGTH = 100
BAR_HEIGHT = 10

#定义白、黑、红、绿、蓝、黄的RGB参数 
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)

#初始化pygame模块，创建游戏窗口、游戏窗口命名、创建跟踪时间对象
pygame.init()
pygame.mixer.init()  #初始化音效
screen = pygame.display.set_mode((WIDTH,HEIGHT))
pygame.display.set_caption("Aircraft Battle")
clock = pygame.time.Clock()

#定义文本字体
font_name = pygame.font.match_font('arial')


#######################################加载图片#######################################
background = pygame.image.load(path.join(img_dir, 'starfield.png')).convert()
background = pygame.transform.scale(background, (WIDTH, 1536))
height = -936

#######################################函数区#######################################

#游戏初始界面和准备开始界面函数
def main_menu():
    global screen
    #加载游戏初始界面背景音乐
    menu_song = pygame.mixer.music.load(path.join(sound_folder,"menu.ogg"))
    #循环播放
    pygame.mixer.music.play(-1)
    #加载游戏初始界面背景图片
    title = pygame.image.load(path.join(img_dir,"main.png")).convert()
    title = pygame.transform.scale(title,(WIDTH, HEIGHT),screen)
    screen.blit(title,(0,0))
    pygame.display.update()
    #检测玩家操作事件
    while True:
        ev = pygame.event.poll()
        if ev.type == pygame.KEYDOWN:
            if ev.key == pygame.K_RETURN:
                break
        elif ev.type == pygame.QUIT:
                pygame.quit()
                quit()
        else:
            draw_text(screen, "Press [ENTER] To Begin", 30, WIDTH/2, HEIGHT/2)
            draw_text(screen, "[A] ←  [S] ↓  [D] →  [W] ↑", 30, WIDTH/2, 2*HEIGHT/3) 
            draw_text(screen, "[Space] fire", 30, WIDTH/2, 3*HEIGHT/4)           
            pygame.display.update()
    #加载准备声音
    ready = pygame.mixer.Sound(path.join(sound_folder,'getready.ogg'))
    ready.play()
    #加载准备开始界面背景颜色和文本
    screen.fill(BLACK)
    draw_text(screen, "GET READY!", 40, WIDTH/2, HEIGHT/3)
    pygame.display.update()

#设置文本属性函数
def draw_text(surf,text,size,x,y):
    #定义文本参数
    font = pygame.font.Font(font_name,size)
    text_surface = font.render(text,True,WHITE)
    text_rect = text_surface.get_rect()
    text_rect.midtop = (x,y)
    surf.blit(text_surface,text_rect)

#######################################主循环#######################################

#定义游戏开始界面标识
running = True
menu_display = True

while running:
    if menu_display:
        main_menu()
        pygame.time.wait(3000)
        pygame.mixer.music.stop()
        pygame.mixer.music.load(path.join(sound_folder,'tgfcoder-FrozenJam-SeamlessLoop.ogg'))
        pygame.mixer.music.play(-1)
        menu_display = False

        score = 0

    clock.tick(FPS)

    pygame.display.flip()    

pygame.quit()